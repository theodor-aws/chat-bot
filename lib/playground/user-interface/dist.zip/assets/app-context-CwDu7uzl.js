import{r as t}from"./index-D8eXXkEU.js";var o=t.useLayoutEffect;const r=t.createContext(null);export{r as A,o as i};
